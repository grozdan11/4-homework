let users = {}; //  Опростено съхранение на потребители в паметта

function login(username, password) {
    if (users[username] && users[username] === password) {
        showHomePage(username);
    } else {
        ons.notification.toast('Invalid credentials', {
            timeout: 2000,
            animation: 'fall'
        });
    }
}

function register(username, password) {
    if (users[username]) {
        ons.notification.toast('Username already exists', {
            timeout: 2000,
            animation: 'fall'
        });
    } else {
        users[username] = password;
        ons.notification.toast('Registration successful', {
            timeout: 2000,
            animation: 'fall'
        });
        showLoginPage();
    }
}

function logout() {
    showLoginPage();
}
