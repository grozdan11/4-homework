function listBooks() {
  document.getElementById('books').innerHTML = '<ons-progress-bar indeterminate></ons-progress-bar>'; // Показва индикатор за зареждане
  fetch(baseUrl)
      .then(response => response.json())
      .then(data => {
          let books = Object.entries(data).map(([id, book]) => ({
              id,
              ...book
          })); // Преобразува обекта в масив
          loadBooksSuccess(books);
      })
      .catch(handleAjaxError);
}

function loadBooksSuccess(books) {
  let booksList = document.getElementById('books');
  booksList.innerHTML = ''; // Изчиства индикатора за зареждане

  if (books && books.length > 0) {
      books.forEach(book => {
          let item = document.createElement('ons-list-item');
          item.innerHTML = `
              <div class="left"><span class="math-inline">\{book\.title\}</div\>
<div class\="right"\>
<ons\-button modifier\="quiet" onclick\="deleteBook\('</span>{book.id}')">Delete</ons-button>
                  <ons-button modifier="quiet" onclick="showEditBook(${JSON.stringify(book)})">Edit</ons-button>
              </div>
          `;
          booksList.appendChild(item);
      });
  } else {
      booksList.innerHTML = '<p>No books found.</p>';
  }
}

function createBook() {
  let title = document.querySelector('#formCreateBook input[name=title]').value;
  let author = document.querySelector('#formCreateBook input[name=author]').value;
  let description = document.querySelector('#formCreateBook textarea[name=descr]').value;

  let bookData = {
      title: title,
      author: author,
      description: description
  };

  fetch(baseUrl, {
          method: "POST",
          headers: {
              "Content-Type": "application/json"
          },
          body: JSON.stringify(bookData)
      })
      .then(response => response.json())
      .then(() => {
          ons.notification.toast('Book created!', {
              timeout: 2000,
              animation: 'lift'
          });
          showListBooks(); //  Navigate to list view
      })
      .catch(handleAjaxError);
}

function editBook() {
  let id = document.querySelector('#formEditBook input[name=id]').value;
  let title = document.querySelector('#formEditBook input[name=title]').value;
  let author = document.querySelector('#formEditBook input[name=author]').value;
  let description = document.querySelector('#formEditBook textarea[name=descr]').value;

  let bookData = {
      title: title,
      author: author,
      description: description
  };

  fetch(baseUrl.replace('books.json', `books/${id}.json`), { //  Construct correct URL for update
          method: "PUT",
          headers: {
              "Content-Type": "application/json"
          },
          body: JSON.stringify(bookData)
      })
      .then(response => response.json())
      .then(() => {
          ons.notification.toast('Book updated!', {
              timeout: 2000,
              animation: 'lift'
          });
          showListBooks(); //  Navigate back to list
      })
      .catch(handleAjaxError);
}

function deleteBook(bookId) {
  ons.openAlertDialog({
      title: 'Confirm',
      message: 'Are you sure you want to delete this book?',
      buttonLabels: ['Cancel', 'Delete'],
      primaryButtonIndex: 1,
      cancelable: true,
      callback: function (index) {
          if (index === 1) {
              fetch(baseUrl.replace('books.json', `books/${bookId}.json`), {
                      method: "DELETE"
                  })
                  .then(response => response.json())
                  .then(() => {
                      ons.notification.toast('Book deleted!', {
                          timeout: 2000,
                          animation: 'fall'
                      });
                      listBooks(); //  Refresh list
                  })
                  .catch(handleAjaxError);
          }
      }
  });
}

function handleAjaxError(error) {
  console.error('AJAX Error:', error);