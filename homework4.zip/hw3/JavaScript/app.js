ons.ready(function () {
  //  Initial setup, if needed
  showLoginPage(); // Показва страницата за вход при стартиране
});

function showHomePage(username) {
  let navigator = document.querySelector('#navigator');
  navigator.resetToPage('home.html', {
      data: {
          username: username
      }
  });
  document.querySelector('#welcome-user').textContent = username || 'guest';
}

function showLoginPage() {
  let navigator = document.querySelector('#navigator');
  navigator.resetToPage('login.html');
}

function showListBooks() {
  document.querySelector('ons-tabbar').setActiveTab(0);
}

function showCreateBook() {
  document.querySelector('ons-tabbar').setActiveTab(1);
}

function showEditBook(book) {
  let navigator = document.querySelector('#navigator');
  navigator.pushPage('edit-book.html', {
      data: {
          book: book
      }
  });
}